include( "shared.lua" )

function ENT:DrawTranslucent()
	self:DrawModel()
end

function ENT:Initialize()
end