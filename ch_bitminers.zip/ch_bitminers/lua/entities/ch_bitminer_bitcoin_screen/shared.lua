ENT.Base = "base_gmodentity"
ENT.Type = "anim"

ENT.PrintName		= "Bitcoin Screen"
ENT.Author			= "Crap-Head"
ENT.Category 		= "Bitminers by Crap-Head"

ENT.Spawnable			= true
ENT.AdminSpawnable		= true

ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
ENT.AutomaticFrameAdvance = true